"""
generator.py
------------
Turns (query + retrieved chunks) into a final natural-language answer.

Three backends are supported (see config.GENERATION_BACKEND):
  - "anthropic"  : calls the Anthropic API (Claude). Needs ANTHROPIC_API_KEY.
  - "openai"     : calls OpenAI's Chat Completions API. Needs OPENAI_API_KEY.
  - "extractive" : no API key required. Builds an answer directly from the
                   retrieved text using simple sentence scoring. Good default
                   so the whole pipeline runs out of the box.
"""

import os
import re
from typing import List, Dict

import config


PROMPT_TEMPLATE = """You are a helpful assistant answering questions using only the provided context.
If the answer is not contained in the context, say you don't have enough information.

Context:
{context}

Question: {question}

Answer clearly and concisely, citing which source(s) you used where relevant."""


def _format_context(chunks: List[Dict]) -> str:
    parts = []
    for c in chunks:
        parts.append(f"[Source: {c['source']} #{c['chunk_id']}]\n{c['text']}")
    return "\n\n".join(parts)


def _generate_anthropic(query: str, chunks: List[Dict]) -> str:
    import anthropic

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise EnvironmentError("ANTHROPIC_API_KEY environment variable is not set.")

    client = anthropic.Anthropic(api_key=api_key)
    prompt = PROMPT_TEMPLATE.format(context=_format_context(chunks), question=query)

    response = client.messages.create(
        model=config.ANTHROPIC_MODEL,
        max_tokens=config.MAX_ANSWER_TOKENS,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(block.text for block in response.content if block.type == "text")


def _generate_openai(query: str, chunks: List[Dict]) -> str:
    from openai import OpenAI

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise EnvironmentError("OPENAI_API_KEY environment variable is not set.")

    client = OpenAI(api_key=api_key)
    prompt = PROMPT_TEMPLATE.format(context=_format_context(chunks), question=query)

    response = client.chat.completions.create(
        model=config.OPENAI_MODEL,
        max_tokens=config.MAX_ANSWER_TOKENS,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.choices[0].message.content


def _generate_extractive(query: str, chunks: List[Dict]) -> str:
    """
    No-API-key fallback. Scores individual sentences from the retrieved
    chunks by word overlap with the query and stitches the best ones
    together into a short answer, with source attribution.
    """
    if not chunks:
        return "I don't have enough information in the indexed documents to answer that."

    query_words = set(w.lower() for w in re.findall(r"\w+", query) if len(w) > 2)

    scored_sentences = []
    for c in chunks:
        sentences = re.split(r"(?<=[.!?])\s+", c["text"])
        for sent in sentences:
            sent = sent.strip()
            if not sent:
                continue
            sent_words = set(w.lower() for w in re.findall(r"\w+", sent))
            overlap = len(query_words & sent_words)
            # combine sentence-level overlap with the chunk's retrieval score
            score = overlap + c["score"]
            scored_sentences.append((score, sent, c["source"], c["chunk_id"]))

    scored_sentences.sort(key=lambda x: x[0], reverse=True)

    # de-duplicate identical/near-identical sentences before taking the top ones
    seen = set()
    deduped = []
    for item in scored_sentences:
        key = item[1].strip().lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)

    top_sentences = deduped[:4]

    if not top_sentences or top_sentences[0][0] <= 0:
        # nothing overlapped meaningfully; fall back to the best chunk verbatim
        best = chunks[0]
        return (f"Based on the most relevant passage found (source: {best['source']}):\n\n"
                f"{best['text']}")

    answer_lines = [s for _, s, _, _ in top_sentences]
    sources = sorted(set(f"{src}#{cid}" for _, _, src, cid in top_sentences))

    answer = " ".join(answer_lines)
    answer += f"\n\n(Derived from: {', '.join(sources)})"
    return answer


def generate_answer(query: str, chunks: List[Dict], backend: str = None) -> str:
    backend = backend or config.GENERATION_BACKEND

    if not chunks:
        return "I couldn't find any relevant information in the indexed documents to answer that question."

    if backend == "anthropic":
        return _generate_anthropic(query, chunks)
    elif backend == "openai":
        return _generate_openai(query, chunks)
    elif backend == "extractive":
        return _generate_extractive(query, chunks)
    else:
        raise ValueError(f"Unknown generation backend: {backend}")


if __name__ == "__main__":
    from indexer import load_index
    from retriever import retrieve

    idx = load_index()
    query = "What is this project about?"
    chunks = retrieve(query, idx)
    answer = generate_answer(query, chunks)
    print(f"Q: {query}\n\nA: {answer}")
