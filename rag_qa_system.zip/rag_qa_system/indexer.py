"""
indexer.py
----------
Builds a searchable index over the document chunks and persists it to disk.

Two embedding backends are supported (see config.EMBEDDING_BACKEND):
  - "tfidf":       scikit-learn TF-IDF vectors. Fast, no downloads, works offline.
  - "sentence_tf": sentence-transformers dense embeddings. Higher quality,
                   requires the `sentence-transformers` package and a one-time
                   model download the first time it runs.
"""

import os
import pickle
from typing import List, Dict

import numpy as np

import config
from document_loader import load_and_chunk_documents


def _build_tfidf_index(chunks: List[Dict]):
    from sklearn.feature_extraction.text import TfidfVectorizer

    texts = [c["text"] for c in chunks]
    vectorizer = TfidfVectorizer(stop_words="english", max_df=0.95, min_df=1)
    matrix = vectorizer.fit_transform(texts)  # sparse matrix, shape (n_chunks, n_terms)

    return {
        "backend": "tfidf",
        "vectorizer": vectorizer,
        "matrix": matrix,
    }


def _build_sentence_tf_index(chunks: List[Dict]):
    from sentence_transformers import SentenceTransformer

    texts = [c["text"] for c in chunks]
    model = SentenceTransformer(config.SENTENCE_TF_MODEL)
    embeddings = model.encode(texts, show_progress_bar=False, normalize_embeddings=True)

    return {
        "backend": "sentence_tf",
        "model_name": config.SENTENCE_TF_MODEL,
        "embeddings": np.array(embeddings),
    }


def build_index(documents_dir: str = None, embedding_backend: str = None) -> Dict:
    """
    Loads + chunks documents, computes embeddings, and returns the index
    as a dict. Does not write to disk (see save_index / build_and_save_index).
    """
    embedding_backend = embedding_backend or config.EMBEDDING_BACKEND

    chunks = load_and_chunk_documents(documents_dir)
    if not chunks:
        raise ValueError("No chunks produced from documents; nothing to index.")

    if embedding_backend == "tfidf":
        vector_data = _build_tfidf_index(chunks)
    elif embedding_backend == "sentence_tf":
        vector_data = _build_sentence_tf_index(chunks)
    else:
        raise ValueError(f"Unknown embedding backend: {embedding_backend}")

    index = {
        "chunks": chunks,          # list of {"source", "chunk_id", "text"}
        "vector_data": vector_data,
    }
    return index


def save_index(index: Dict, index_dir: str = None) -> None:
    index_dir = index_dir or config.INDEX_DIR
    os.makedirs(index_dir, exist_ok=True)

    meta_path = os.path.join(index_dir, "index.pkl")
    with open(meta_path, "wb") as f:
        pickle.dump(index, f)


def load_index(index_dir: str = None) -> Dict:
    index_dir = index_dir or config.INDEX_DIR
    meta_path = os.path.join(index_dir, "index.pkl")

    if not os.path.exists(meta_path):
        raise FileNotFoundError(
            f"No index found at '{meta_path}'. Run indexing first, e.g.:\n"
            f"    python main.py index"
        )

    with open(meta_path, "rb") as f:
        return pickle.load(f)


def build_and_save_index(documents_dir: str = None, embedding_backend: str = None,
                          index_dir: str = None) -> Dict:
    index = build_index(documents_dir, embedding_backend)
    save_index(index, index_dir)
    return index


if __name__ == "__main__":
    idx = build_and_save_index()
    print(f"Indexed {len(idx['chunks'])} chunks using backend "
          f"'{idx['vector_data']['backend']}'.")
    print(f"Index saved to: {config.INDEX_DIR}")
