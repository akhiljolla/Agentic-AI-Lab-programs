"""
retriever.py
------------
Given a loaded index and a user query, retrieves the top-k most relevant
document chunks using cosine similarity in the chosen embedding space.
"""

from typing import List, Dict

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

import config


def _retrieve_tfidf(query: str, index: Dict, top_k: int) -> List[Dict]:
    vectorizer = index["vector_data"]["vectorizer"]
    matrix = index["vector_data"]["matrix"]

    query_vec = vectorizer.transform([query])
    scores = cosine_similarity(query_vec, matrix).flatten()

    return scores


def _retrieve_sentence_tf(query: str, index: Dict, top_k: int) -> List[Dict]:
    from sentence_transformers import SentenceTransformer

    model_name = index["vector_data"]["model_name"]
    embeddings = index["vector_data"]["embeddings"]

    model = SentenceTransformer(model_name)
    query_vec = model.encode([query], normalize_embeddings=True)

    scores = cosine_similarity(query_vec, embeddings).flatten()
    return scores


def retrieve(query: str, index: Dict, top_k: int = None,
             min_similarity: float = None) -> List[Dict]:
    """
    Returns a list of the top_k most relevant chunks, each augmented with
    a 'score' field, sorted by descending relevance.
    """
    top_k = top_k or config.TOP_K
    min_similarity = min_similarity if min_similarity is not None else config.MIN_SIMILARITY

    backend = index["vector_data"]["backend"]
    if backend == "tfidf":
        scores = _retrieve_tfidf(query, index, top_k)
    elif backend == "sentence_tf":
        scores = _retrieve_sentence_tf(query, index, top_k)
    else:
        raise ValueError(f"Unknown embedding backend: {backend}")

    chunks = index["chunks"]
    ranked_idx = np.argsort(scores)[::-1][:top_k]

    results = []
    for i in ranked_idx:
        score = float(scores[i])
        if score < min_similarity:
            continue
        result = dict(chunks[i])
        result["score"] = score
        results.append(result)

    return results


if __name__ == "__main__":
    from indexer import load_index

    idx = load_index()
    query = "What is this project about?"
    hits = retrieve(query, idx)
    print(f"Query: {query}\n")
    for h in hits:
        print(f"[{h['score']:.3f}] {h['source']} #{h['chunk_id']}: {h['text'][:120]}...")
