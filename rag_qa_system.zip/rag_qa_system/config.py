"""
config.py
---------
Central configuration for the RAG Question Answering system.
Edit these values to tune chunking, retrieval, and generation behavior.
"""

import os

# ----- Paths -----
DOCUMENTS_DIR = os.path.join(os.path.dirname(__file__), "documents")
INDEX_DIR = os.path.join(os.path.dirname(__file__), "index_store")
INDEX_META_FILE = os.path.join(INDEX_DIR, "index_meta.pkl")
INDEX_VECTORS_FILE = os.path.join(INDEX_DIR, "index_vectors.pkl")

# ----- Chunking -----
CHUNK_SIZE = 500        # approx. characters per chunk
CHUNK_OVERLAP = 100     # characters of overlap between consecutive chunks

# ----- Retrieval -----
TOP_K = 4                # number of chunks to retrieve per query
MIN_SIMILARITY = 0.05    # ignore chunks below this cosine similarity score

# ----- Embedding backend -----
# "tfidf"       -> scikit-learn TF-IDF vectors (no internet / model download needed)
# "sentence_tf" -> sentence-transformers dense embeddings (needs the package +
#                  a one-time model download from the internet)
EMBEDDING_BACKEND = os.environ.get("RAG_EMBEDDING_BACKEND", "tfidf")
SENTENCE_TF_MODEL = "all-MiniLM-L6-v2"

# ----- Generation backend -----
# "anthropic"  -> call Claude via the Anthropic API (needs ANTHROPIC_API_KEY)
# "openai"     -> call OpenAI's Chat Completions API (needs OPENAI_API_KEY)
# "extractive" -> no API key needed; builds an answer directly from retrieved text
GENERATION_BACKEND = os.environ.get("RAG_GENERATION_BACKEND", "extractive")

ANTHROPIC_MODEL = "claude-sonnet-4-6"
OPENAI_MODEL = "gpt-4o-mini"

MAX_ANSWER_TOKENS = 500
