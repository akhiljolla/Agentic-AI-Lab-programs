"""
document_loader.py
-------------------
Loads raw documents (.txt, .md) from a folder and splits them into
overlapping chunks suitable for indexing and retrieval.
"""

import os
import glob
from typing import List, Dict

import config


def _read_text_file(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def load_documents(documents_dir: str = None) -> List[Dict]:
    """
    Load all supported files from documents_dir.
    Returns a list of dicts: {"source": filename, "text": full_text}
    """
    documents_dir = documents_dir or config.DOCUMENTS_DIR
    supported_ext = ("*.txt", "*.md")

    files = []
    for ext in supported_ext:
        files.extend(glob.glob(os.path.join(documents_dir, "**", ext), recursive=True))

    if not files:
        raise FileNotFoundError(
            f"No .txt or .md files found in '{documents_dir}'. "
            f"Add some documents there before indexing."
        )

    docs = []
    for path in sorted(files):
        text = _read_text_file(path)
        if text.strip():
            docs.append({"source": os.path.relpath(path, documents_dir), "text": text})
    return docs


def chunk_text(text: str, chunk_size: int = None, overlap: int = None) -> List[str]:
    """
    Split text into overlapping chunks by character count, breaking on
    sentence/paragraph boundaries where possible so chunks stay coherent.
    """
    chunk_size = chunk_size or config.CHUNK_SIZE
    overlap = overlap or config.CHUNK_OVERLAP

    text = " ".join(text.split())  # normalize whitespace
    if len(text) <= chunk_size:
        return [text] if text else []

    chunks = []
    start = 0
    text_len = len(text)

    while start < text_len:
        end = min(start + chunk_size, text_len)

        # try to break on a sentence boundary near the end of the window
        if end < text_len:
            boundary = text.rfind(". ", start, end)
            if boundary != -1 and boundary > start + chunk_size * 0.5:
                end = boundary + 1

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        if end >= text_len:
            break
        start = max(end - overlap, start + 1)  # advance with overlap, always progress

    return chunks


def load_and_chunk_documents(documents_dir: str = None) -> List[Dict]:
    """
    Convenience function: load documents and split each into chunks.
    Returns a list of dicts: {"source": filename, "chunk_id": int, "text": chunk_text}
    """
    docs = load_documents(documents_dir)
    all_chunks = []
    for doc in docs:
        chunks = chunk_text(doc["text"])
        for i, chunk in enumerate(chunks):
            all_chunks.append({
                "source": doc["source"],
                "chunk_id": i,
                "text": chunk,
            })
    return all_chunks


if __name__ == "__main__":
    chunks = load_and_chunk_documents()
    print(f"Loaded {len(chunks)} chunks from {config.DOCUMENTS_DIR}")
    for c in chunks[:3]:
        print("---")
        print(f"[{c['source']} #{c['chunk_id']}] {c['text'][:150]}...")
