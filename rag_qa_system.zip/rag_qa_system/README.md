# RAG-Based Question Answering System

A complete, self-contained Retrieval-Augmented Generation (RAG) pipeline in plain Python:
**indexing → retrieval → generation**. Runs out of the box with no API key required, and
can optionally be upgraded to use Claude, OpenAI, or dense sentence-transformer embeddings.

## Folder contents

```
rag_qa_system/
├── config.py              # all settings (chunk size, top_k, backends, etc.)
├── document_loader.py     # loads .txt/.md files and splits them into chunks
├── indexer.py              # builds embeddings and saves the index to disk
├── retriever.py             # cosine-similarity search over the index
├── generator.py             # turns retrieved chunks into a final answer
├── main.py                   # command-line entry point (index / query / chat)
├── requirements.txt
├── documents/                # <-- put your own .txt / .md files here
│   ├── rag_overview.txt       (sample doc, included so the demo works instantly)
│   └── embeddings_and_search.txt
└── index_store/               # generated automatically by `python main.py index`
```

## 1. Install dependencies

```bash
pip install -r requirements.txt
```

Only `numpy` and `scikit-learn` are required for the default setup (TF-IDF retrieval +
extractive answer generation — no API key, no internet needed at query time).

## 2. Add your documents

Drop any `.txt` or `.md` files into the `documents/` folder (subfolders are fine too).
Two sample documents are already included so you can try the system immediately.

## 3. Build the index

```bash
python main.py index
```

This reads every file in `documents/`, splits it into overlapping chunks, computes
vector representations, and saves everything to `index_store/index.pkl`.

## 4. Ask questions

Single question:
```bash
python main.py query "What are the three stages of a RAG pipeline?"
```

Interactive chat:
```bash
python main.py chat
```

## Configuration

All tunable behavior lives in `config.py`, and the two backend choices can also be set
via environment variables so you don't have to edit code:

| Setting | Env var | Options | Default |
|---|---|---|---|
| Embedding backend | `RAG_EMBEDDING_BACKEND` | `tfidf`, `sentence_tf` | `tfidf` |
| Generation backend | `RAG_GENERATION_BACKEND` | `extractive`, `anthropic`, `openai` | `extractive` |

### Using dense embeddings (better semantic matching)
```bash
pip install sentence-transformers
export RAG_EMBEDDING_BACKEND=sentence_tf
python main.py index      # re-index with the new backend
```

### Using Claude to generate answers
```bash
pip install anthropic
export ANTHROPIC_API_KEY=your-key-here
export RAG_GENERATION_BACKEND=anthropic
python main.py query "your question"
```

### Using OpenAI to generate answers
```bash
pip install openai
export OPENAI_API_KEY=your-key-here
export RAG_GENERATION_BACKEND=openai
python main.py query "your question"
```

## How it works

1. **Indexing** (`document_loader.py` + `indexer.py`): documents are loaded, normalized,
   and split into ~500-character overlapping chunks. Each chunk is converted into a
   vector (TF-IDF by default) and the full set of chunk vectors is saved to disk.
2. **Retrieval** (`retriever.py`): the user's question is embedded the same way, cosine
   similarity is computed against every indexed chunk, and the top-k most similar chunks
   are returned.
3. **Generation** (`generator.py`): the retrieved chunks are assembled into a context
   block and combined with the question. By default an extractive method scores and
   stitches together the most relevant sentences (no API key needed); optionally, the
   context + question are sent to Claude or OpenAI to produce a fluent generated answer.

## Notes

- Re-run `python main.py index` any time you add, remove, or edit files in `documents/`.
- `MIN_SIMILARITY` in `config.py` filters out weakly-related chunks; lower it if queries
  are returning "not enough information" too often, or raise it to be stricter.
- The `extractive` generation backend is intentionally dependency-free so the whole
  system works immediately after `pip install -r requirements.txt` — switch to
  `anthropic` or `openai` for more natural, synthesized answers.
