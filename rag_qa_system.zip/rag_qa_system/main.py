"""
main.py
-------
Command-line entry point for the RAG Question Answering system.

Usage:
    python main.py index                     # build the index from documents/
    python main.py query "your question"      # ask a single question
    python main.py chat                        # interactive Q&A loop

Environment variables (optional, only needed for API-based generation):
    RAG_GENERATION_BACKEND = anthropic | openai | extractive   (default: extractive)
    RAG_EMBEDDING_BACKEND  = tfidf | sentence_tf                (default: tfidf)
    ANTHROPIC_API_KEY       (required if RAG_GENERATION_BACKEND=anthropic)
    OPENAI_API_KEY          (required if RAG_GENERATION_BACKEND=openai)
"""

import sys
import argparse

import config
from indexer import build_and_save_index, load_index
from retriever import retrieve
from generator import generate_answer


def cmd_index(args):
    print(f"Indexing documents from: {config.DOCUMENTS_DIR}")
    print(f"Embedding backend: {config.EMBEDDING_BACKEND}")
    idx = build_and_save_index()
    print(f"Done. Indexed {len(idx['chunks'])} chunks into '{config.INDEX_DIR}'.")


def _answer_question(question: str, verbose: bool = True):
    idx = load_index()
    chunks = retrieve(question, idx)

    if verbose:
        print("\nTop retrieved chunks:")
        for c in chunks:
            preview = c["text"][:100].replace("\n", " ")
            print(f"  [{c['score']:.3f}] {c['source']} #{c['chunk_id']}: {preview}...")

    answer = generate_answer(question, chunks)
    return answer


def cmd_query(args):
    answer = _answer_question(args.question)
    print(f"\nQuestion: {args.question}")
    print(f"\nAnswer:\n{answer}")


def cmd_chat(args):
    print("RAG Q&A interactive mode. Type 'exit' or 'quit' to stop.\n")
    try:
        load_index()
    except FileNotFoundError as e:
        print(str(e))
        sys.exit(1)

    while True:
        try:
            question = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not question:
            continue
        if question.lower() in ("exit", "quit"):
            print("Goodbye.")
            break

        answer = _answer_question(question, verbose=False)
        print(f"Assistant: {answer}\n")


def build_parser():
    parser = argparse.ArgumentParser(description="RAG-based Question Answering System")
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_index = subparsers.add_parser("index", help="Build the document index")
    p_index.set_defaults(func=cmd_index)

    p_query = subparsers.add_parser("query", help="Ask a single question")
    p_query.add_argument("question", type=str, help="The question to ask")
    p_query.set_defaults(func=cmd_query)

    p_chat = subparsers.add_parser("chat", help="Interactive Q&A session")
    p_chat.set_defaults(func=cmd_chat)

    return parser


if __name__ == "__main__":
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)
