# Text-to-SQL Workflow (Retrieval + Generation)

An end-to-end LLM workflow that converts natural-language questions into
SQL, executes them against a real SQLite database, and returns the results.

```
NL question
    │
    ▼
[1] Retrieval  (src/schema_retriever.py)
    TF-IDF similarity over table/column descriptions selects the top-k
    most relevant tables for the question ("schema linking"), so the
    generation step only sees the schema it needs instead of the whole DB.
    │
    ▼
[2] Generation (src/sql_generator.py + src/llm_client.py)
    Builds a prompt containing the retrieved schema + question, sends it
    to Claude (Anthropic Messages API) to generate a SQL query, then
    validates the output (SELECT-only, no destructive keywords).
    │
    ▼
[3] Execution  (src/pipeline.py)
    Runs the validated SQL against the SQLite database and returns
    columns + rows.
```

## Folder contents

```
text2sql_pipeline/
├── data/
│   ├── create_database.py   # builds the sample e-commerce SQLite DB
│   └── ecommerce.db         # generated database (5 tables, seeded data)
├── src/
│   ├── schema_retriever.py  # retrieval component (TF-IDF schema linking)
│   ├── llm_client.py        # Anthropic API client + offline fallback
│   ├── sql_generator.py     # prompt construction + SQL validation
│   └── pipeline.py          # orchestrates retrieval -> generation -> execution
├── outputs/
│   └── execution_log.txt    # log from the last run of run_demo.py
├── run_demo.py               # runs 8 example questions end-to-end
├── requirements.txt
└── README.md
```

## Database

A sample e-commerce database with 5 tables: `categories`, `products`,
`customers`, `orders`, `order_items` — seeded with 40 customers, 16
products, 150 orders and ~400 order line items.

## Setup

```bash
pip install -r requirements.txt
python data/create_database.py   # (re)build the sample database
```

## Running the demo

```bash
python run_demo.py
```

This runs 8 example natural-language questions through the full pipeline
and prints/logs the retrieved tables, generated SQL, and query results.

### Using real Claude-generated SQL

By default (no API key), the pipeline uses a transparent, rule-based
offline fallback for SQL generation (see `_offline_fallback` in
`src/llm_client.py`) purely so this project runs immediately without
credentials.

To generate SQL with Claude instead, set your API key before running:

```bash
export ANTHROPIC_API_KEY=your_key_here
python run_demo.py
```

`llm_client.py` will automatically detect the key and switch to real
Anthropic API calls (`model: claude-sonnet-4-6`), building on the exact
same retrieval + validation + execution pipeline.

## Using it programmatically

```python
from src.pipeline import TextToSQLPipeline

pipeline = TextToSQLPipeline()
result = pipeline.run("What are the best selling products by units sold?")

print(result.sql)      # generated SQL
print(result.columns)  # result column names
print(result.rows)     # result rows
```

## Design notes

- **Retrieval** uses TF-IDF (scikit-learn) rather than a neural embedding
  model so the project runs fully offline with no model downloads. Swap in
  `sentence-transformers` embeddings in `schema_retriever.py` for higher
  retrieval quality on larger schemas.
- **Generation** is Claude-based via the Anthropic Messages API, with strict
  validation (`SELECT`-only, no destructive keywords) before any query
  touches the database.
- **Safety**: the pipeline never executes non-`SELECT` statements, so it is
  safe to point at a real database with read access only.
