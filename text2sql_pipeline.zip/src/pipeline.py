"""
pipeline.py
-----------
End-to-end Text-to-SQL pipeline:

  Natural-language question
        |
        v
  [1] SchemaRetriever  -> retrieves the most relevant tables (RAG-style schema linking)
        |
        v
  [2] SQLGenerator      -> builds a prompt with retrieved schema, calls the LLM, validates SQL
        |
        v
  [3] SQLite execution   -> runs the query against the real database
        |
        v
  Results (+ generated SQL + retrieved tables, for transparency)
"""

import sqlite3
import os
from dataclasses import dataclass, field
from typing import List, Any

from src.schema_retriever import SchemaRetriever
from src.sql_generator import SQLGenerator, SQLGenerationError
from src.llm_client import LLMClient

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "ecommerce.db")


@dataclass
class QueryResult:
    question: str
    retrieved_tables: List[str]
    sql: str
    columns: List[str] = field(default_factory=list)
    rows: List[Any] = field(default_factory=list)
    error: str = None


class TextToSQLPipeline:
    def __init__(self, db_path: str = DB_PATH, top_k_tables: int = 3):
        self.db_path = db_path
        self.top_k_tables = top_k_tables
        self.retriever = SchemaRetriever(db_path)
        self.generator = SQLGenerator(LLMClient())

    def run(self, question: str) -> QueryResult:
        # Step 1: Retrieval
        retrieved_docs = self.retriever.retrieve(question, top_k=self.top_k_tables)
        schema_context = "\n\n".join(doc.ddl + ";" for doc in retrieved_docs)
        table_names = [doc.table_name for doc in retrieved_docs]

        # Step 2: Generation
        try:
            sql = self.generator.generate(question, schema_context)
        except SQLGenerationError as e:
            return QueryResult(question=question, retrieved_tables=table_names, sql="", error=str(e))

        # Step 3: Execution
        try:
            columns, rows = self._execute(sql)
        except sqlite3.Error as e:
            return QueryResult(question=question, retrieved_tables=table_names, sql=sql, error=f"SQLite error: {e}")

        return QueryResult(
            question=question,
            retrieved_tables=table_names,
            sql=sql,
            columns=columns,
            rows=rows,
        )

    def _execute(self, sql: str):
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute(sql)
        columns = [desc[0] for desc in cur.description] if cur.description else []
        rows = cur.fetchall()
        conn.close()
        return columns, rows


if __name__ == "__main__":
    pipeline = TextToSQLPipeline()
    result = pipeline.run("Which customers have placed the most orders?")
    print("Question:", result.question)
    print("Retrieved tables:", result.retrieved_tables)
    print("Generated SQL:\n", result.sql)
    print("Columns:", result.columns)
    print("Rows:", result.rows)
