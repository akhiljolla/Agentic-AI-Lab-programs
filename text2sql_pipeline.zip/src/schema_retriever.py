"""
schema_retriever.py
--------------------
Retrieval component of the Text-to-SQL workflow.

Given a natural-language question, this module retrieves the most relevant
tables (and their columns) from the database schema, so the SQL-generation
step only receives the schema context it actually needs instead of the full
database schema. This mirrors how production Text-to-SQL / RAG systems do
"schema linking" before generation, which keeps prompts small and reduces
hallucinated table/column names on large databases.

Retrieval is implemented with TF-IDF + cosine similarity (scikit-learn) over
natural-language descriptions of each table (its name, columns, and a short
semantic description). This requires no external model downloads, so it
runs fully offline.
"""

import sqlite3
from dataclasses import dataclass, field
from typing import List

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


@dataclass
class TableDoc:
    table_name: str
    columns: List[str]
    description: str
    ddl: str

    @property
    def text(self) -> str:
        """Flattened natural-language representation used for embedding."""
        return (
            f"Table {self.table_name}. "
            f"Columns: {', '.join(self.columns)}. "
            f"{self.description}"
        )


# Hand-written semantic descriptions for each table. In a real system these
# could be pulled from DB comments, a data catalog, or auto-summarized by an
# LLM once at indexing time.
TABLE_DESCRIPTIONS = {
    "categories": "Product categories used to group products, e.g. Electronics, Books.",
    "products": "Products available for sale, including price and stock quantity, linked to a category.",
    "customers": "Registered customers/users, including name, email, country and signup date.",
    "orders": "Customer orders placed, including order date and status (completed, pending, cancelled, shipped).",
    "order_items": "Individual line items belonging to an order: which product, quantity, and price paid.",
}


class SchemaRetriever:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.table_docs: List[TableDoc] = []
        self._vectorizer = None
        self._doc_matrix = None
        self._build_index()

    # ---------- indexing ----------
    def _load_schema_from_sqlite(self) -> List[TableDoc]:
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute(
            "SELECT name, sql FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%'"
        )
        rows = cur.fetchall()
        docs = []
        for table_name, ddl in rows:
            cur.execute(f"PRAGMA table_info({table_name})")
            cols = [r[1] for r in cur.fetchall()]
            desc = TABLE_DESCRIPTIONS.get(table_name, "")
            docs.append(TableDoc(table_name=table_name, columns=cols, description=desc, ddl=ddl))
        conn.close()
        return docs

    def _build_index(self):
        self.table_docs = self._load_schema_from_sqlite()
        corpus = [doc.text for doc in self.table_docs]
        self._vectorizer = TfidfVectorizer(stop_words="english")
        self._doc_matrix = self._vectorizer.fit_transform(corpus)

    # ---------- retrieval ----------
    def retrieve(self, question: str, top_k: int = 3) -> List[TableDoc]:
        """Return the top_k most relevant TableDoc objects for the question."""
        query_vec = self._vectorizer.transform([question])
        sims = cosine_similarity(query_vec, self._doc_matrix)[0]
        ranked = sorted(
            zip(self.table_docs, sims), key=lambda x: x[1], reverse=True
        )
        # Always include tables with nonzero similarity; pad with top ones
        # if fewer than top_k are relevant so joins remain possible.
        selected = [doc for doc, score in ranked[:top_k]]
        return selected

    def relevant_schema_context(self, question: str, top_k: int = 3) -> str:
        """Return a compact schema string (CREATE TABLE statements) for the
        retrieved tables, ready to inject into an LLM prompt."""
        docs = self.retrieve(question, top_k=top_k)
        return "\n\n".join(doc.ddl + ";" for doc in docs)

    def full_schema_context(self) -> str:
        return "\n\n".join(doc.ddl + ";" for doc in self.table_docs)


if __name__ == "__main__":
    retriever = SchemaRetriever("../data/ecommerce.db")
    q = "Which customers have placed the most orders?"
    print(f"Question: {q}\n")
    print("Retrieved schema context:\n")
    print(retriever.relevant_schema_context(q))
