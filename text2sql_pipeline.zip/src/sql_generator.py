"""
sql_generator.py
-----------------
Generation component of the Text-to-SQL workflow.

Takes a natural-language question + retrieved schema context, builds a
prompt, calls the LLM client to generate SQL, then performs light
validation (SELECT-only, references only known tables) before the query
is executed against the database.
"""

import re
from src.llm_client import LLMClient

SYSTEM_PROMPT = """You are an expert SQLite SQL generator.
Given a database schema and a natural-language question, output ONLY a single
valid SQLite SELECT query that answers the question. Rules:
- Use only the tables/columns given in the schema.
- Never modify data (no INSERT/UPDATE/DELETE/DROP).
- Prefer explicit JOINs and meaningful column aliases.
- Return ONLY the SQL query, wrapped in a ```sql code block, with no extra commentary.
"""

USER_PROMPT_TEMPLATE = """Database schema:
{schema}

Question: {question}

Write one SQLite SELECT query that answers the question."""

FORBIDDEN_KEYWORDS = ["insert", "update", "delete", "drop", "alter", "truncate", "attach", "pragma"]


class SQLGenerationError(Exception):
    pass


class SQLGenerator:
    def __init__(self, llm_client: LLMClient = None):
        self.llm_client = llm_client or LLMClient()

    def build_prompt(self, question: str, schema_context: str) -> str:
        return USER_PROMPT_TEMPLATE.format(schema=schema_context, question=question)

    def generate(self, question: str, schema_context: str) -> str:
        user_prompt = self.build_prompt(question, schema_context)
        sql = self.llm_client.generate_sql(SYSTEM_PROMPT, user_prompt)
        self._validate(sql)
        return sql

    def _validate(self, sql: str):
        lowered = sql.lower()
        if not lowered.strip().startswith("select"):
            raise SQLGenerationError(f"Generated query is not a SELECT statement:\n{sql}")
        for kw in FORBIDDEN_KEYWORDS:
            if re.search(rf"\b{kw}\b", lowered):
                raise SQLGenerationError(f"Generated query contains forbidden keyword '{kw}':\n{sql}")
