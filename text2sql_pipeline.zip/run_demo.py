"""
run_demo.py
-----------
Runs the end-to-end Text-to-SQL workflow (retrieval -> generation -> SQL
execution) on a set of example natural-language questions, prints the
results, and writes a full execution log to outputs/execution_log.txt.

Usage:
    python run_demo.py

Set ANTHROPIC_API_KEY in your environment to use real Claude-generated SQL.
Without it, the pipeline automatically uses a transparent offline
rule-based fallback (see src/llm_client.py) so this script always runs.
"""

import os
import sys
import io

sys.path.insert(0, os.path.dirname(__file__))

from src.pipeline import TextToSQLPipeline
from src.llm_client import LLMClient

QUESTIONS = [
    "Which customers have placed the most orders?",
    "What is the total revenue from all non-cancelled orders?",
    "What are the best selling products by units sold?",
    "How many products are in each category?",
    "How many orders are in each status?",
    "Which countries do our customers come from, ranked by number of customers?",
    "Which products have the lowest stock quantity?",
    "What is the average order value?",
]


def main():
    log_lines = []

    def log(msg=""):
        print(msg)
        log_lines.append(str(msg))

    pipeline = TextToSQLPipeline()
    mode = "ONLINE (Anthropic API)" if pipeline.generator.llm_client.online else "OFFLINE (rule-based fallback, no ANTHROPIC_API_KEY set)"

    log("=" * 80)
    log("TEXT-TO-SQL WORKFLOW — END-TO-END DEMO")
    log(f"Generation mode: {mode}")
    log("=" * 80)

    for i, question in enumerate(QUESTIONS, 1):
        log(f"\n[{i}] QUESTION: {question}")
        result = pipeline.run(question)
        log(f"    Retrieved tables : {result.retrieved_tables}")
        log(f"    Generated SQL    :\n{_indent(result.sql)}")
        if result.error:
            log(f"    ERROR: {result.error}")
            continue
        log(f"    Columns          : {result.columns}")
        log(f"    Result rows ({len(result.rows)} total, showing up to 5):")
        for row in result.rows[:5]:
            log(f"        {row}")

    log("\n" + "=" * 80)
    log("DEMO COMPLETE")
    log("=" * 80)

    out_dir = os.path.join(os.path.dirname(__file__), "outputs")
    os.makedirs(out_dir, exist_ok=True)
    log_path = os.path.join(out_dir, "execution_log.txt")
    with open(log_path, "w") as f:
        f.write("\n".join(log_lines))
    print(f"\nFull execution log written to: {log_path}")


def _indent(text, spaces=8):
    pad = " " * spaces
    return "\n".join(pad + line for line in text.splitlines())


if __name__ == "__main__":
    main()
