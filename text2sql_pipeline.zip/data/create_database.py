"""
create_database.py
-------------------
Creates a sample e-commerce SQLite database (ecommerce.db) with realistic
schema and seed data. This is the target database our Text-to-SQL workflow
will query.

Tables:
  categories   - product categories
  products     - products for sale
  customers    - registered customers
  orders       - customer orders
  order_items  - line items within an order

Run:
  python create_database.py
"""

import sqlite3
import os
import random
from datetime import datetime, timedelta

DB_PATH = os.path.join(os.path.dirname(__file__), "ecommerce.db")

SCHEMA_SQL = """
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS customers;

CREATE TABLE categories (
    category_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    category_name   TEXT NOT NULL UNIQUE
);

CREATE TABLE products (
    product_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    product_name    TEXT NOT NULL,
    category_id     INTEGER NOT NULL,
    unit_price      REAL NOT NULL,
    stock_quantity  INTEGER NOT NULL,
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

CREATE TABLE customers (
    customer_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name      TEXT NOT NULL,
    last_name       TEXT NOT NULL,
    email           TEXT NOT NULL UNIQUE,
    country         TEXT NOT NULL,
    signup_date     TEXT NOT NULL
);

CREATE TABLE orders (
    order_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id     INTEGER NOT NULL,
    order_date      TEXT NOT NULL,
    status          TEXT NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE order_items (
    order_item_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id        INTEGER NOT NULL,
    product_id      INTEGER NOT NULL,
    quantity        INTEGER NOT NULL,
    unit_price      REAL NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);
"""

CATEGORIES = ["Electronics", "Books", "Home & Kitchen", "Sports & Outdoors", "Toys"]

PRODUCTS = [
    ("Wireless Mouse", "Electronics", 19.99),
    ("Mechanical Keyboard", "Electronics", 59.99),
    ("4K Monitor", "Electronics", 249.99),
    ("USB-C Hub", "Electronics", 29.99),
    ("Noise Cancelling Headphones", "Electronics", 129.99),
    ("Python Crash Course", "Books", 34.99),
    ("Data Science Handbook", "Books", 42.50),
    ("Science Fiction Anthology", "Books", 15.99),
    ("Non-stick Frying Pan", "Home & Kitchen", 24.99),
    ("Coffee Maker", "Home & Kitchen", 89.99),
    ("Blender", "Home & Kitchen", 45.00),
    ("Yoga Mat", "Sports & Outdoors", 22.00),
    ("Running Shoes", "Sports & Outdoors", 74.99),
    ("Camping Tent", "Sports & Outdoors", 159.99),
    ("Building Blocks Set", "Toys", 39.99),
    ("Remote Control Car", "Toys", 49.99),
]

FIRST_NAMES = ["Alice", "Bob", "Carla", "David", "Elena", "Farhan", "Grace",
               "Hiro", "Isabel", "Jamal", "Katya", "Liam", "Mei", "Noah", "Omar"]
LAST_NAMES = ["Smith", "Johnson", "Garcia", "Kumar", "Chen", "Rossi", "Silva",
              "Brown", "Wilson", "Nguyen", "Khan", "Muller", "Park", "Ivanov"]
COUNTRIES = ["USA", "India", "Germany", "Brazil", "UK", "Canada", "Japan", "Australia"]
STATUSES = ["completed", "pending", "cancelled", "shipped"]


def build_database():
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.executescript(SCHEMA_SQL)

    # categories
    cat_ids = {}
    for name in CATEGORIES:
        cur.execute("INSERT INTO categories (category_name) VALUES (?)", (name,))
        cat_ids[name] = cur.lastrowid

    # products
    product_ids = []
    for name, cat, price in PRODUCTS:
        stock = random.randint(5, 200)
        cur.execute(
            "INSERT INTO products (product_name, category_id, unit_price, stock_quantity) "
            "VALUES (?, ?, ?, ?)",
            (name, cat_ids[cat], price, stock),
        )
        product_ids.append(cur.lastrowid)

    # customers
    random.seed(42)
    customer_ids = []
    start_date = datetime(2023, 1, 1)
    for i in range(40):
        fn = random.choice(FIRST_NAMES)
        ln = random.choice(LAST_NAMES)
        email = f"{fn.lower()}.{ln.lower()}{i}@example.com"
        country = random.choice(COUNTRIES)
        signup = (start_date + timedelta(days=random.randint(0, 600))).strftime("%Y-%m-%d")
        cur.execute(
            "INSERT INTO customers (first_name, last_name, email, country, signup_date) "
            "VALUES (?, ?, ?, ?, ?)",
            (fn, ln, email, country, signup),
        )
        customer_ids.append(cur.lastrowid)

    # orders + order_items
    for _ in range(150):
        cust = random.choice(customer_ids)
        order_date = (start_date + timedelta(days=random.randint(0, 700))).strftime("%Y-%m-%d")
        status = random.choice(STATUSES)
        cur.execute(
            "INSERT INTO orders (customer_id, order_date, status) VALUES (?, ?, ?)",
            (cust, order_date, status),
        )
        order_id = cur.lastrowid

        for _ in range(random.randint(1, 4)):
            pid = random.choice(product_ids)
            cur.execute("SELECT unit_price FROM products WHERE product_id = ?", (pid,))
            price = cur.fetchone()[0]
            qty = random.randint(1, 5)
            cur.execute(
                "INSERT INTO order_items (order_id, product_id, quantity, unit_price) "
                "VALUES (?, ?, ?, ?)",
                (order_id, pid, qty, price),
            )

    conn.commit()
    conn.close()
    print(f"Database created at: {DB_PATH}")


if __name__ == "__main__":
    build_database()
